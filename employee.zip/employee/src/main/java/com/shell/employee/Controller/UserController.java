package com.shell.employee.Controller;

import com.shell.employee.Entity.User;
import com.shell.employee.Service.UserService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/user")
@AllArgsConstructor
public class UserController {
    @Autowired
    private UserService userService;

    //    @PostMapping()
//    public ResponseEntity<User> createUser(@RequestBody User user) {
//        User saveUser=userService.createUser(user);
//        return new ResponseEntity<>(saveUser, HttpStatus.CREATED);
//
//    }
    @PostMapping("addUser")
    public User addUser(@RequestBody User user) {
        return userService.saveUser(user);
    }

    @GetMapping("getList")
    public List<User> getList() {
        return userService.getList();
    }

    @DeleteMapping("deleteById/{id}")
    public String deleteById(@PathVariable("id") Long id) {
        userService.deleteById(id);
        return "Successfully Deleted";
    }

    @GetMapping("getById/{id}")
    public Optional<User> getById(@PathVariable("id") Long id) {
        return userService.getById(id);
    }

}
